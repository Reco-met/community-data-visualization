var config = {
    style: 'mapbox://styles/themax22/cm84wbmqv004h01s9amb07gts',
    accessToken: 'pk.eyJ1IjoidGhlbWF4MjIiLCJhIjoiY204NDZzZGRpMGM1MDJrcXRrMHptcmd1bSJ9.Dtt3rUT_V3-kGwzYfxaN4g',
    showMarkers: false,
    markerColor: '#3FB1CE',
    //projection: 'equirectangular',
    //Read more about available projections here
    //https://docs.mapbox.com/mapbox-gl-js/example/projections/
    inset: false,
    theme: 'light',
    use3dTerrain: false, //set true for enabling 3D maps.
    auto: false,
    title: 'Unlock Singapore: Explore · Experience · Share',
    subtitle: 'A Journey Through Singapore Nature, Culture, and Urban Life',
    byline: 'By huixin',
    footer: 'Created using <a href="https://github.com/mapbox/storytelling" target="_blank">Mapbox Storytelling</a> template.',

    
    chapters: [
        {
            id: 'nature-walks',
            alignment: 'left',
            hidden: false,
            title: 'Singapore Green Spaces: Where City and Nature Meet',
            description: ' Singapore parks and trails are not just green patches on a map— they are part of daily life. A morning jog along park connectors, a quiet moment under a century-old tree, or a weekend escape into nature reserves—these spaces shape our routines, memories, and connections. This map brings together the trails we walk, the heritage trees we pass, and the water bodies that cool the city.<br><br><img src="images/1.png" style="height:100%; width:250px;"></img>',
            location: {
                center: [103.75, 1.36],
                zoom: 10.8,
                pitch: 0,
                bearing: 0
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'mapbox-satellite',
                    opacity: 0.1,
                    visibility: 'visible'               
                },
                {
                    layer: 'tracks',
                    opacity: 1 ,
                    visibility: 'visible'               
                },
                {
                    layer: 'parks',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'heritage trees',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'traffic',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01,   
                    visibility: 'none'            
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01    ,
                    visibility: 'none'           
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01 ,
                    visibility: 'none'               
                }
            ],

            onChapterExit: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'water',
                    opacity: 1,
                    visibility: 'visible'                
                },
                {
                    layer: 'tracks',
                    opacity: 0.01,
                    visibility: 'none'               
                },
                {
                    layer: 'parks',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'traffic',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01,
                    visibility: 'none'               
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01 ,
                    visibility: 'none'               
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01 ,
                    visibility: 'none'               
                }
                
            ]
        },
        
        {
            id: 'historic-routes',
            alignment: 'right',
            hidden: false,
            title: 'Singapore Heritage: Layers of Time in the City',
            description: 'Some streets whisper the past, while others wear it proudly. This map traces Singapore heritage through its conserved districts, historic landmarks, and the unseen patterns of history revealed in the heatmap. Wander through shophouse-lined streets, stand where generations once gathered, and uncover the quiet corners where history lingers. The past is not just preserved—it is part of the city rhythm, shaping the spaces we move through every day.<br><br><img src="images/2.png" style="height:100%; width:250px;"></img>',
            location: {
                center: [103.90, 1.36],
                zoom: 10.8,
                pitch: 0,
                bearing: 0,
                // flyTo additional controls-
                // These options control the flight curve, making it move
                // slowly and zoom out almost completely before starting
                // to pan.
                //speed: 2, // make the flying slow
                //curve: 1, // change the speed at which it zooms out
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'water',
                    opacity: 1 ,
                    visibility: 'visible'              
                },
                {
                    layer: 'tracks',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'parks',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'traffic',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'historic sites',
                    opacity: 1,
                    visibility: 'visible'                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.3,
                    visibility: 'visible'                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01,
                    visibility: 'none'                
                }
            ],

            onChapterExit: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'water',
                    opacity: 1,
                    visibility: 'visible'                
                },
                {
                    layer: 'tracks',
                    opacity: 0.01,
                    visibility: 'none'               
                },
                {
                    layer: 'parks',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'traffic',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01,
                    visibility: 'none'                
                }
                
            ]
        },
        {
            id: 'food-shopping',
            alignment: 'left',
            hidden: false,
            title: 'Singapore Commercial Pulse: Walk Through the City Energy',
            description: 'Some streets never sleep. From lively market stalls to gleaming office towers, Singapore commercial districts have evolved from historic trade routes into a global hub of business and culture. This map lets you step into the city energy—where deals are made, trends are set, and people come together. Wander through heritage shophouses once filled with merchants, feel the rhythm of bustling shopping streets, or explore the towering financial core shaping tomorrow economy.<br><br><img src="images/3.png" style="height:100%; width:250px;"></img>',
            location: {
                center: [103.75, 1.36],
                zoom: 10.8,
                pitch: 0,
                bearing: 0
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'water',
                    opacity: 1,
                    visibility: 'visible'               
                },
                {
                    layer: 'tracks',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'parks',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'traffic',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.8,
                    visibility: 'visible'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.5,
                    visibility: 'visible'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01,
                    visibility: 'none'                
                }
            ],

            onChapterExit: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'water',
                    opacity: 1,
                    visibility: 'visible'                
                },
                {
                    layer: 'tracks',
                    opacity: 0.01,
                    visibility: 'none'               
                },
                {
                    layer: 'parks',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'traffic',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01,
                    visibility: 'none'               
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01,
                    visibility: 'none'                
                }
                
            ]
        },
        {
            id: 'nightlife-hotspots',
            alignment: 'right',
            hidden: false,
            title: 'Singapore After Dark: The City Nightscape',
            description: 'As daylight fades, a new rhythm takes over the city. From vibrant nightlife districts to quiet 24-hour spots, Singapore after-dark energy is mapped out here—showing where the crowds gather, businesses stay open, and the city keeps moving. Whether it is a buzzing entertainment hub, a late-night eatery, or a pocket of quiet activity, this map reveals where Singapore stays awake while the rest of the city sleeps.<br><br><img src="images/4.png" style="height:100%; width:250px;"></img>',
            location: {
                center: [103.90, 1.36],
                zoom: 10.8,
                pitch: 0,
                bearing: 0,
                // flyTo additional controls-
                // These options control the flight curve, making it move
                // slowly and zoom out almost completely before starting
                // to pan.
                //speed: 2, // make the flying slow
                //curve: 1, // change the speed at which it zooms out
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'water',
                    opacity: 1,
                    visibility: 'visible'               
                },
                {
                    layer: 'tracks',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'parks',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'traffic',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01 ,
                    visibility: 'none'               
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01 ,
                    visibility: 'none'              
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 1 ,
                    visibility: 'visible'               
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 1,
                    visibility: 'visible'                
                }
            ],

            onChapterExit: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'water',
                    opacity: 1,
                    visibility: 'visible'                
                },
                {
                    layer: 'tracks',
                    opacity: 0.01 ,
                    visibility: 'none'              
                },
                {
                    layer: 'parks',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'traffic',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01 ,
                    visibility: 'none'               
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01,
                    visibility: 'none'       
                }
            ]
        }
    ]
};