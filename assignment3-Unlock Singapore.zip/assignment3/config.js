var config = {
    style: 'mapbox://styles/themax22/cm84l1kz4003d01qz85enbe32',
    accessToken: 'pk.eyJ1IjoidGhlbWF4MjIiLCJhIjoiY204NDZzZGRpMGM1MDJrcXRrMHptcmd1bSJ9.Dtt3rUT_V3-kGwzYfxaN4g',
    showMarkers: false,
    markerColor: '#3FB1CE',
    //projection: 'equirectangular',
    //Read more about available projections here
    //https://docs.mapbox.com/mapbox-gl-js/example/projections/
    inset: false,
    theme: 'light',
    use3dTerrain: false, //set true for enabling 3D maps.
    auto: false,
    title: 'Unlock Singapore: Explore · Experience · Share',
    subtitle: 'A Journey Through Singapore Nature, Culture, and Urban Life',
    byline: 'By huixin',
    footer: 'Created using <a href="https://github.com/mapbox/storytelling" target="_blank">Mapbox Storytelling</a> template.',
    chapters: [
        {
            id: 'nature-walks',
            alignment: 'left',
            hidden: false,
            title: 'Nature & Green Walks',
            description: ' Explore Singapore lush greenery, scenic trails, and tranquil parks. This map highlights nature reserves, walking trails, and heritage trees, offering insights into the city green spaces. With terrain visualization and park facilities, it guides users through the best eco-friendly routes for hiking, jogging, and relaxation..<br><br><img src="images/1.png" style="height:100%; width:250px;"></img>',
            location: {
                center: [103.75, 1.36],
                zoom: 10.8,
                pitch: 0,
                bearing: 0
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'water',
                    opacity: 1,
                    visibility: 'visible'               
                },
                {
                    layer: 'tracks',
                    opacity: 1 ,
                    visibility: 'visible'               
                },
                {
                    layer: 'parks',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'heritage trees',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'terrain',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01,   
                    visibility: 'none'            
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01    ,
                    visibility: 'none'           
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01 ,
                    visibility: 'none'               
                }
            ],

            onChapterExit: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01,
                     visibility: 'none'
                },
                {
                    layer: 'water',
                    opacity: 1,
                    visibility: 'visible'                
                },
                {
                    layer: 'tracks',
                    opacity: 0.01,
                    visibility: 'none'               
                },
                {
                    layer: 'parks',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'terrain',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'museums',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01,
                    visibility: 'none'               
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01 ,
                    visibility: 'none'               
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01 ,
                    visibility: 'none'               
                }
                
            ]
        },
        
        {
            id: 'historic-routes',
            alignment: 'right',
            hidden: false,
            title: 'Historic & Cultural Routes',
            description: 'Step into Singapore rich history through its preserved landmarks, heritage districts, and iconic museums. This map showcases historical sites, conservation areas, and cultural hotspots, allowing users to experience the diverse architectural and historical narratives that shaped the city.<br><br><img src="images/2.png" style="height:100%; width:250px;"></img>',
            location: {
                center: [103.90, 1.36],
                zoom: 10.8,
                pitch: 0,
                bearing: 0,
                // flyTo additional controls-
                // These options control the flight curve, making it move
                // slowly and zoom out almost completely before starting
                // to pan.
                //speed: 2, // make the flying slow
                //curve: 1, // change the speed at which it zooms out
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'water',
                    opacity: 1 ,
                    visibility: 'visible'              
                },
                {
                    layer: 'tracks',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'parks',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'terrain',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'museums',
                    opacity: 1,
                    visibility: 'visible'
                },
                {
                    layer: 'historic sites',
                    opacity: 1,
                    visibility: 'visible'                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.3,
                    visibility: 'visible'                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01,
                    visibility: 'none'
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01,
                    visibility: 'none'                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01,
                    visibility: 'none'                
                }
            ],

            onChapterExit: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01
                },
                {
                    layer: 'water',
                    opacity: 1                
                },
                {
                    layer: 'tracks',
                    opacity: 0.01               
                },
                {
                    layer: 'parks',
                    opacity: 0.01
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01
                },
                {
                    layer: 'terrain',
                    opacity: 0.01
                },
                {
                    layer: 'museums',
                    opacity: 0.01
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01                
                }
                
            ]
        },
        {
            id: 'food-shopping',
            alignment: 'left',
            hidden: false,
            title: 'Food & Shopping Streets',
            description: 'Discover Singapore vibrant shopping districts and famous food streets. From bustling hawker centers to lively commercial areas, this map highlights the best spots for culinary delights and retail experiences. Walkable shopping streets are emphasized to enhance pedestrian-friendly exploration.<br><br><img src="images/3.png" style="height:100%; width:250px;"></img>',
            location: {
                center: [103.75, 1.36],
                zoom: 10.8,
                pitch: 0,
                bearing: 0
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01
                },
                {
                    layer: 'water',
                    opacity: 1               
                },
                {
                    layer: 'tracks',
                    opacity: 0.01                
                },
                {
                    layer: 'parks',
                    opacity: 0.01
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01
                },
                {
                    layer: 'terrain',
                    opacity: 0.01
                },
                {
                    layer: 'museums',
                    opacity: 0.01
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.8
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 1
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.5
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01                
                }
            ],

            onChapterExit: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01
                },
                {
                    layer: 'water',
                    opacity: 1                
                },
                {
                    layer: 'tracks',
                    opacity: 0.01               
                },
                {
                    layer: 'parks',
                    opacity: 0.01
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01
                },
                {
                    layer: 'terrain',
                    opacity: 0.01
                },
                {
                    layer: 'museums',
                    opacity: 0.01
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01               
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01                
                }
                
            ]
        },
        {
            id: 'nightlife-hotspots',
            alignment: 'right',
            hidden: false,
            title: 'Nightlife Hotspots',
            description: 'Experience Singapore dynamic nightlife, from buzzing nightclubs to 24-hour eateries. This map highlights key entertainment zones, late-night dining spots, and night bus routes, helping users navigate the city’s after-dark scene while ensuring accessible and safe nighttime travel.<br><br><img src="images/4.png" style="height:100%; width:250px;"></img>',
            location: {
                center: [103.90, 1.36],
                zoom: 10.8,
                pitch: 0,
                bearing: 0,
                // flyTo additional controls-
                // These options control the flight curve, making it move
                // slowly and zoom out almost completely before starting
                // to pan.
                //speed: 2, // make the flying slow
                //curve: 1, // change the speed at which it zooms out
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01
                },
                {
                    layer: 'water',
                    opacity: 1               
                },
                {
                    layer: 'tracks',
                    opacity: 0.01                
                },
                {
                    layer: 'parks',
                    opacity: 0.01
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01
                },
                {
                    layer: 'terrain',
                    opacity: 0.01
                },
                {
                    layer: 'museums',
                    opacity: 0.01
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01               
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 1
                },
                {
                    layer: '24h-411u2b',
                    opacity: 1                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 1                
                }
            ],

            onChapterExit: [
                {
                    layer: 'parks and nature reserves',
                    opacity: 0.01
                },
                {
                    layer: 'water',
                    opacity: 1                
                },
                {
                    layer: 'tracks',
                    opacity: 0.01               
                },
                {
                    layer: 'parks',
                    opacity: 0.01
                },
                {
                    layer: 'heritage trees',
                    opacity: 0.01
                },
                {
                    layer: 'terrain',
                    opacity: 0.01
                },
                {
                    layer: 'museums',
                    opacity: 0.01
                },
                {
                    layer: 'historic sites',
                    opacity: 0.01                
                },
                {
                    layer: 'historical conservation area',
                    opacity: 0.01                
                },
                {
                    layer: 'walkable-area-related-to-commericial',
                    opacity: 0.01
                },
                {
                    layer: 'hawkercentresgeojson-5evs26',
                    opacity: 0.01
                },
                {
                    layer: 'commercial-area-2nlv4t',
                    opacity: 0.01
                },
                {
                    layer: 'night-bus-line-3a4qrv',
                    opacity: 0.01
                },
                {
                    layer: '24h-411u2b',
                    opacity: 0.01                
                },
                {
                    layer: 'night-site-c9gend',
                    opacity: 0.01       
                }
            ]
        }
    ]
};